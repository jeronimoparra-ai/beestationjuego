# MANUAL DE IMPLEMENTACIÓN TÉCNICA Y DESPLIEGUE MULTIJUGADOR (V2)
# BeeStation: Misión Néctar — Guardianes del Jardín

---

## 1. ARQUITECTURA AUTORITATIVA CENTRALIZADA

Para permitir que múltiples celulares físicos jueguen en tiempo real conectados a la misma red Wi-Fi del stand, se sustituyó el esquema basado en `BroadcastChannel` local por un **Servidor Autoritativo Ligero en Node.js**:

```mermaid
flowchart TD
    subgraph Stand Ferial SENA (Red Wi-Fi Local)
        SRV["🖥️ Servidor Local Node.js (server.js:8080)<br/>• Estado Autoritativo de Sala<br/>• Temporizador 30s<br/>• Generador QR Dinámico (/api/qr)<br/>• Motor de Reflexiones Ecológicas"]
        TV["📺 Televisor 16:9 (tv.html)"]
        MOB1["📱 Celular Visitante 1 (mobile.html)"]
        MOB2["📱 Celular Visitante 2 (mobile.html)"]
        ORG["🎛️ Consola Organizador (organizer.html)"]
    end

    TV <-->|"WebSocket Bidireccional (JSON)"| SRV
    MOB1 <-->|"WebSocket Bidireccional (JSON)"| SRV
    MOB2 <-->|"WebSocket Bidireccional (JSON)"| SRV
    ORG <-->|"WebSocket Bidireccional (JSON)"| SRV
```

### 1.1 Contratos de Eventos WebSocket
| Evento | Dirección | Propósito |
|---|---|---|
| `JOIN_ROOM` | Cliente -> Servidor | El jugador envía su nombre, personaje y avatar elegido. |
| `START_COUNTDOWN` | Organizador / TV -> Servidor | Dispara la cuenta regresiva sincronizada de 3 segundos. |
| `TAP_FLOWER` | Celular -> Servidor | Notifica toque en una ranura de flor (`slotIndex`). |
| `NECTAR_COLLECTED` | Servidor -> Todos | Informa puntos ganados, racha, multiplicador, bonificación cooperativa y progreso de la colmena. |
| `TIMER_UPDATE` | Servidor -> Todos | Segundo actual (30 a 0) y momento de ritmo (1, 2 o 3). |
| `PLAYER_RESULT_CARD`| Servidor -> Celular individual | Entrega estadísticas individuales y reflexión ecológica personalizada. |
| `GAME_OVER` | Servidor -> Todos | Cierre de partida colectiva y podio. |
| `SET_BOTS` | Organizador -> Servidor | Configura entre 0 y 50 bots para simular afluencia en feria. |
| `RESET_ROOM` | Organizador -> Servidor | Devuelve la sala al estado LOBBY. |

---

## 2. INSTRUCCIONES EXACTAS DE EJECUCIÓN EN WINDOWS

### Paso 1: Abrir Terminal en la Carpeta del Proyecto
```powershell
cd C:\Users\andre\beestationjuego\Mision_Nectar_Antigravity
```

### Paso 2: Iniciar el Servidor Multijugador
```powershell
node server.js
```

El servidor detectará automáticamente la tarjeta de red Wi-Fi y mostrará en consola:
```
================================================================
🐝 BEESTATION: MISIÓN NÉCTAR — GUARDIANES DEL JARDÍN (V2)
📡 Servidor Local WebSocket + HTTP activo en puerto: 8080
🌐 Acceso Pantalla TV: http://localhost:8080/tv.html
📱 Acceso Celulares LAN: http://192.168.1.7:8080/mobile.html?room=STAND-SENA-01
🎛️ Consola Organizador: http://localhost:8080/organizer.html
🔬 Telemetría BeeStation IoT: http://localhost:8080/telemetry.html
================================================================
```

---

## 3. PROCEDIMIENTO PARA EL STAND DE FERIA (TV + CELULARES FÍSICOS)

1. **Configurar el Router Wi-Fi del Stand:**
   - Conectar la computadora donde corre `server.js` al router Wi-Fi del stand (o habilitar la zona Wi-Fi móvil del PC/laptop).
2. **Proyectar el Televisor:**
   - En la computadora, abrir el navegador en pantalla completa (tecla F11) en: `http://localhost:8080/tv.html`.
   - La pantalla proyectará a Mielita, el jardín, la colmena y el **código QR dinámico funcional**.
3. **Participación de los Visitantes:**
   - Los visitantes apuntan la cámara de su teléfono inteligente al código QR del televisor.
   - El teléfono abre directamente la dirección Wi-Fi local sin instalar aplicaciones ni ingresar contraseñas.
4. **Control del Facilitador / Organizador:**
   - En una tableta o ventana secundaria, abrir `http://localhost:8080/organizer.html`.
   - Presionar `▶ Iniciar Cuenta Regresiva (3s)` cuando haya participantes listos.
   - Si no hay visitantes en ese instante, deslizar la barra de bots para inyectar un enjambre de prueba.
