# BEESTATION BRIDGE & TELEMETRÍA EDUCATIVA V2
# BeeStation: Misión Néctar — Guardianes del Jardín

---

## 1. PROPÓSITO DEL PUENTE NARRATIVO Y CIENTÍFICO

Al finalizar la partida arcade de 30 segundos y leer su reflexión ecológica, el visitante puede hacer clic en **"Conoce la Tecnología BeeStation IoT"**.

Mielita realiza la conexión entre la colmena virtual del juego y el proyecto de ingeniería real:
> **MIELITA:**  
> *"En el juego recolectamos néctar tocando flores, pero en la vida real... ¿cómo sabemos qué sucede dentro de una colmena viva sin dañarla ni abrirla? ¡Con BeeStation! Un nodo inteligente desarrollado en el SENA Centro Minero Ambiental que monitorea las variables del nido sin interrumpir la labor de las abejas."*

---

## 2. HARDWARE REAL DEL NODO BEESTATION (FIRMWARE ESP32)

Basado en la auditoría exhaustiva del repositorio oficial del **SENA Centro Minero Ambiental** (`beestation_node.ino` y `acustica.h`), el hardware instrumentado corresponde a:

| Componente | Conexión / Bus | Parámetros Medidos | Función en la Colmena |
|---|---|---|---|
| **ESP32 DevKit** | Microcontrolador central | Reloj NTP, WiFi local, Hash SHA-256 y Firma ECDSA P-256 | Gestiona la lectura de sensores y transmite JSON firmado a `api/ingest.php`. |
| **BME280** | I2C (SDA=GPIO21, SCL=GPIO22) | Temperatura (°C), Humedad relativa (%), Presión atmosférica (hPa) | Monitorea la cámara de cría (termorregulación óptima entre 34.5°C y 35.5°C) y previene condensaciones dañinas. |
| **BH1750** | I2C (compartido) | Iluminancia / Luz exterior (lux) | Correlaciona la intensidad de luz solar con el inicio y fin del pecoreo diario de las abejas. |
| **HX711 + Celda de carga** | GPIO 16 (DOUT), GPIO 4 (SCK) | Peso total de la colmena (kg) | Permite registrar fluctuaciones de masa. *(Nota de rigurosidad: calibración en curso; la variación de peso no demuestra de forma directa la producción neta de miel).* |
| **Micrófono MAX4466** | ADC1 (GPIO analógico) | Frecuencia acústica dominante (Hz) | Estimación de tono dominante mediante **cruces por cero con histéresis** (método ligero en C, sin FFT). |
| **Tarjeta microSD** | Bus VSPI (MOSI=23, MISO=19, CLK=18, CS=5) | Almacenamiento local en CSV/TXT | **Es un soporte de almacenamiento local**, no un sensor. Guarda lecturas ante caídas de enlace. |

---

## 3. PRECAUCIONES CIENTÍFICAS Y PEDAGÓGICAS OBLIGATORIAS

Para mantener la máxima rigurosidad técnica exigida por el SENA:

1. **Sin invenciones de hardware:** El firmware actual **NO** utiliza sensores DHT22, sondas DS18B20 ni sensores de CO2. Tampoco cuenta con paneles solares o baterías instrumentadas en la telemetría oficial.
2. **Sin transformadas de Fourier (FFT):** El algoritmo de `acustica.h` utiliza cruces por cero con histéresis para estimar la frecuencia media de una señal tonal dominante. Se presenta como una herramienta experimental y no como un diagnóstico clínico infalible de la reina.
3. **Calibración de la Báscula:** El peso de una colmena cambia por salidas masivas de abejas, evaporación de agua en el néctar, consumo interno y condiciones climáticas.
4. **Etiquetado Indispensable:** Todas las pantallas de demostración del videojuego llevan la etiqueta visible:  
   **DATOS DE DEMOSTRACIÓN SIMULADOS (Proyecto de formación SENA Centro Minero Ambiental)**.
