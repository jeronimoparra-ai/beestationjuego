# GAME DESIGN DOCUMENT (GDD V2)
# BeeStation: Misión Néctar — Guardianes del Jardín

**Versión:** 2.0 (Rediseño y Evolución Integral Antigravity)  
**Género:** Videojuego Arcade Cooperativo, Familiar, Dinámico y Multijugador en Tiempo Real  
**Plataformas:** Pantalla TV 16:9 (Panorámica / Stand) + Celulares Móviles Web (Controladores Táctiles Wi-Fi LAN) + Consola de Organizador  
**Público:** Niños desde 5 años, jóvenes y adultos en ferias científicas del SENA Centro Minero Ambiental (El Bagre, Antioquia).  
**Duración Total de Partida:** Exactamente **30 segundos de juego activo** (más 3s de cuenta regresiva y lectura pausada de la reflexión final).  
**Premisa Central:**  
> *Ya no se trata únicamente de tocar flores para conseguir puntos. Se trata de trabajar como un enjambre para llenar la colmena, proteger el jardín y descubrir por qué las abejas son tan importantes para la naturaleza.*

---

## 1. LOS TRES MOMENTOS DE RITMO EN 30 SEGUNDOS

Para garantizar dinamismo sin alargar la partida ni fragmentarla en pantallas de carga, los 30 segundos se dividen en tres momentos de ritmo:

```
[ 0s ---------------- 5s ]   Momento 1: Primer Vuelo (Enseñar jugando)
[ 6s --------------- 20s ]   Momento 2: El Jardín Despierta (Flores Doradas, Combos y Cooperación)
[ 21s -------------- 30s ]   Momento 3: Frenesí de Néctar (Lluvia de Polen y Clímax Colectivo)
```

### 1.1 Momento 1 — Primer Vuelo (0 a 5 segundos)
- **Objetivo:** Comprensión instantánea en menos de 5 segundos sin leer manuales.
- **Mecánica:** Aparecen flores silvestres comunes (Margaritas y Lirios). Mielita indica: *«¡Toca las flores que brillan!»*.
- **Sensación:** Primeras recompensas inmediatas (+10 pts por flor), sonido dulce de gota y estallido de polen.

### 1.2 Momento 2 — El Jardín Despierta (6 a 20 segundos)
- **Objetivo:** Adrenalina, coordinación individual y sinergia colectiva.
- **Flores Doradas Especiales:** Brotan inesperadamente con destellos rotatorios (30 puntos y 3 gotas a la colmena).
- **Sistema de Rachas (Combos):**
  - 3 flores válidas consecutivas: **Multiplicador x2** (Puntos dobles).
  - 6 flores válidas consecutivas: **Multiplicador x3** (Puntos triples y estela dorada).
- **Bonificación Cooperativa del Enjambre:**
  - Si 2 o más participantes humanos tocan flores dentro de una ventana temporal de 2.5 segundos, el servidor activa una **Bonificación Colectiva**:
  - Mielita anuncia en el TV: *«¡El enjambre está trabajando unido! ¡BONIFICACIÓN COLECTIVA!»*.
  - Todos los participantes reciben +20 puntos de bono y la colmena se llena con +4 gotas adicionales.

### 1.3 Momento 3 — Frenesí de Néctar y Lluvia de Polen (21 a 30 segundos)
- **Objetivo:** Clímax visual y auditivo de alta intensidad.
- **Acontecimiento Especial:** *Lluvia de Polen*.
- **Comportamiento:** Aumenta la probabilidad de flores doradas al 45%, la música acelera su tempo a 140 BPM, el cielo del jardín adopta un tono dorado crepuscular y la colmena pulsa con ondas luminosas.
- **Cuenta Regresiva Final:** Los últimos 5 segundos se marcan con campanas rítmicas crecientes.

---

## 2. ECONOMÍA DEL NÉCTAR Y PROGRESO COLECTIVO

| Acción / Evento | Recompensa Individual | Aporte a la Colmena | Frecuencia |
|---|---|---|---|
| **Flor Común** | 10 pts (x Multiplicador) | +1 Gota de Miel | Base (75% en M1 y M2) |
| **Flor Dorada Especial** | 30 pts (x Multiplicador) | +3 Gotas de Miel | 25% en M2, 45% en M3 |
| **Racha x2 (3 flores)** | Puntos x2 | Normal | Al mantener ritmo de toque |
| **Racha x3 (6 flores)** | Puntos x3 | Normal | Al encadenar 6 flores seguidas |
| **Bonificación Cooperativa**| +20 pts extra para participantes | +4 Gotas extra colectivas | Sinergia en ventana de 2.5s |

### 2.1 Calibración Adaptativa de la Colmena
Para que el objetivo sea emocionante y alcanzable tanto para 2 personas como para un grupo grande:
$$\text{Meta de Gotas} = \max(40, N_{\text{jugadores humanos}} \times 15)$$
Si el enjambre supera el 100%, la colmena entra en **Modo Reserva Real**, acumulando el excedente en frascos laterales visibles en la pantalla de TV.

---

## 3. CIERRE EDUCATIVO: EL MENSAJE DE MIELITA

Al llegar el temporizador a 00:00:
1. **En el Televisor:** Mielita celebra el logro del grupo: *«¡Lo conseguimos, exploradores! Cada pequeña abeja aportó algo especial para nuestra colmena.»*
2. **En cada Celular:** Se presenta una tarjeta individual interactiva permanente que no se cierra hasta que el jugador lo desee.

### 3.1 Motor de Reflexiones Ambientales Personalizadas
Basado estrictamente en estadísticas reales registradas por el servidor autoritativo:

| Perfil Registrado | Criterio Real | Reflexión Ecológica Personalizada |
|---|---|---|
| **Explorador de Flores** | Visitó $\ge 4$ especies botánicas | *«¡Qué gran explorador! En la naturaleza, las abejas visitan diversas flores y transportan polen entre ellas, ayudando a muchas plantas a reproducirse. Cada visita tiene un propósito.»* |
| **Maestro de los Combos**| Mejor racha $\ge 5$ consecutivas | *«¡Qué habilidad! Las abejas realizan múltiples viajes en busca de alimento. Su actividad incansable de recolección y polinización ayuda a mantener muchos ecosistemas.»* |
| **Guardián del Enjambre**| Participó en $\ge 2$ Bonos Cooperativos | *«¡Trabajaste en equipo! Las abejas viven en colonias con roles especializados. Su organización y colaboración son fundamentales para la supervivencia de la colmena.»* |
| **Amigo de la Naturaleza**| Participación constante ($\ge 5$ flores) | *«¡Cada aporte cuenta! Las abejas necesitan flores y espacios naturales para alimentarse. Proteger sus hábitats ayuda a conservar a todos los polinizadores.»* |
| **Coleccionista Dorado** | Cosechó $\ge 3$ Flores Doradas | *«¡Descubriste flores especiales! La diversidad floral ofrece distintos nutrientes a los polinizadores. Conservar plantas nativas y praderas florales salva a las abejas.»* |
| **Abeja Solidaria** | Aporte general al enjambre | *«¡Tu aporte hizo la diferencia! En los ecosistemas, cada ser vivo cumple una misión. Las abejas sostienen la biodiversidad vegetal mediante la polinización.»* |

### 3.2 Pregunta de Curiosidad y Compromiso Práctico
- **Pregunta:** *«¿Qué pasaría si las abejas desaparecieran? Muchas plantas dependen de los polinizadores para reproducirse. Proteger a las abejas también es proteger la biodiversidad y los alimentos de los que dependemos. ¡Proteger a las abejas también es proteger nuestra vida!»*
- **Compromiso Ambiental:** Botones interactivos donde el visitante puede elegir su compromiso:
  1. Cuidar las flores y plantas de su entorno.
  2. Evitar destruir los lugares donde anidan los polinizadores.
  3. Conocer las plantas nativas de su región.
  4. Compartir con su familia y amigos la importancia de las abejas.
