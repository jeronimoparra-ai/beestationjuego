/**
 * Suite de Pruebas Automatizadas de Integración y QA Multijugador
 * BeeStation: Misión Néctar — Guardianes del Jardín
 */

const http = require('http');
const { WebSocket } = require('ws');

const PORT = 8089;
process.env.PORT = PORT.toString();

// Cargar servidor
require('../server.js');

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function runTests() {
  console.log('--- INICIANDO QA Y PRUEBAS AUTOMATIZADAS MULTIJUGADOR ---');
  let testsPassed = 0;
  let testsFailed = 0;

  function assert(condition, testName) {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      testsPassed++;
    } else {
      console.error(`❌ [FAIL] ${testName}`);
      testsFailed++;
    }
  }

  await delay(1200); // Esperar inicio del servidor

  // Prueba 1: Endpoint /api/info
  await new Promise((resolve) => {
    http.get(`http://localhost:${PORT}/api/info`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          assert(res.statusCode === 200, 'HTTP GET /api/info status 200');
          assert(!!json.lanIp && !!json.mobileUrl, 'Contiene IP LAN y URL móvil válida');
        } catch (e) {
          assert(false, 'Parse JSON /api/info');
        }
        resolve();
      });
    }).on('error', (err) => {
      assert(false, 'Conexión a /api/info falló: ' + err.message);
      resolve();
    });
  });

  // Prueba 2: Endpoint /api/qr (Generador SVG auténtico)
  await new Promise((resolve) => {
    http.get(`http://localhost:${PORT}/api/qr`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        assert(res.statusCode === 200, 'HTTP GET /api/qr status 200');
        assert(data.includes('<svg') && data.includes('</svg>'), 'El QR devuelto es un SVG vectorial válido');
        resolve();
      });
    }).on('error', () => {
      assert(false, 'Conexión a /api/qr');
      resolve();
    });
  });

  // Prueba 3: Conexión WebSocket simultánea (TV + Jugador 1 + Jugador 2)
  const wsTv = new WebSocket(`ws://localhost:${PORT}`);
  const wsPlayer1 = new WebSocket(`ws://localhost:${PORT}`);
  const wsPlayer2 = new WebSocket(`ws://localhost:${PORT}`);

  await delay(600);

  assert(wsTv.readyState === WebSocket.OPEN, 'Cliente TV conectado por WebSocket');
  assert(wsPlayer1.readyState === WebSocket.OPEN, 'Jugador 1 conectado por WebSocket');
  assert(wsPlayer2.readyState === WebSocket.OPEN, 'Jugador 2 conectado por WebSocket');

  // Registrar jugadores
  wsPlayer1.send(JSON.stringify({
    type: 'JOIN_ROOM',
    payload: { id: 'p1_test', name: 'Explorador Alfa', character: 'coral' }
  }));

  wsPlayer2.send(JSON.stringify({
    type: 'JOIN_ROOM',
    payload: { id: 'p2_test', name: 'Explorador Beta', character: 'menta' }
  }));

  await delay(500);

  // Iniciar Cuenta Regresiva desde TV
  wsTv.send(JSON.stringify({ type: 'START_COUNTDOWN' }));
  await delay(3600); // Esperar 3s de countdown + inicio de partida

  // Prueba 4: Tocar flores y verificar Combo y Bonificación Cooperativa
  let p1Score = 0;
  let coopBonusTriggered = false;

  wsTv.on('message', (raw) => {
    const msg = JSON.parse(raw);
    if (msg.type === 'NECTAR_COLLECTED') {
      if (msg.payload.playerId === 'p1_test') p1Score = msg.payload.points;
      if (msg.payload.coopBonus) coopBonusTriggered = true;
    }
  });

  // Taps simultáneos en ventana de 2.5s
  wsPlayer1.send(JSON.stringify({
    type: 'TAP_FLOWER',
    payload: { playerId: 'p1_test', slotIndex: 0 }
  }));

  wsPlayer2.send(JSON.stringify({
    type: 'TAP_FLOWER',
    payload: { playerId: 'p2_test', slotIndex: 1 }
  }));

  await delay(800);

  assert(p1Score >= 10, 'Jugador 1 recolectó néctar y sumó puntos');
  assert(coopBonusTriggered === true, 'Bonificación Cooperativa del Enjambre activada por toques simultáneos');

  // Cerrar sockets de prueba
  wsTv.close();
  wsPlayer1.close();
  wsPlayer2.close();

  console.log(`\n--- RESULTADO DE PRUEBAS: ${testsPassed} Pasadas, ${testsFailed} Fallidas ---`);
  process.exit(testsFailed === 0 ? 0 : 1);
}

runTests();
