/**
 * BeeStation: Misión Néctar — Guardianes del Jardín
 * Motor de Juego Cliente (Lógica de estados, feedback sensorial y sincronización con servidor)
 */

class NectarGameCore {
  constructor({ role = 'mobile' } = {}) {
    this.role = role; // 'tv', 'mobile', 'organizer'
    this.state = 'LOBBY'; // LOBBY, COUNTDOWN, PLAYING, RESULTS, TELEMETRY
    this.duration = 30;
    this.timeLeft = 30;
    this.moment = 1; // 1: 0-5s (Primer Vuelo), 2: 6-20s (Jardín Despierta), 3: 21-30s (Frenesí de Néctar)

    // Métricas colectivas
    this.hiveTargetDrops = 50;
    this.hiveCurrentDrops = 0;
    this.overflowDrops = 0;
    this.totalScore = 0;

    // Participantes
    this.players = new Map();
    this.localPlayer = null;
    this.personalResultCard = null;

    // Flores (6 ranuras)
    this.flowers = [];

    // Racha local y combos
    this.localStreak = 0;
    this.localMultiplier = 1;

    this.initSyncListeners();
  }

  initSyncListeners() {
    if (!window.networkSync) return;

    // Sincronización completa de estado al conectar
    window.networkSync.on('ROOM_STATE', (payload) => {
      this.state = payload.state;
      this.timeLeft = payload.timeLeft;
      this.moment = payload.moment || 1;
      this.hiveTargetDrops = payload.targetDrops || 50;
      this.hiveCurrentDrops = payload.currentDrops || 0;
      this.overflowDrops = payload.overflowDrops || 0;
      if (payload.flowers) {
        this.flowers = payload.flowers;
        if (this.onFlowersUpdated) this.onFlowersUpdated(this.flowers);
      }
      if (this.onStateChanged) this.onStateChanged(this.state, payload);
    });

    // Actualización de lista de jugadores
    window.networkSync.on('PLAYERS_UPDATED', (payload) => {
      this.players.clear();
      if (payload.players) {
        payload.players.forEach(p => this.players.set(p.id, p));
      }
      if (this.onPlayersUpdated) this.onPlayersUpdated(payload);
    });

    // Inicio de cuenta regresiva sincronizada (3, 2, 1)
    window.networkSync.on('START_COUNTDOWN', (payload) => {
      this.state = 'COUNTDOWN';
      if (window.audioSystem) window.audioSystem.playTick();
      if (this.onStateChanged) this.onStateChanged('COUNTDOWN', payload);
      if (this.onCountdownTick) this.onCountdownTick(payload.count || 3);
    });

    window.networkSync.on('COUNTDOWN_TICK', (payload) => {
      if (window.audioSystem) window.audioSystem.playTick();
      if (this.onCountdownTick) this.onCountdownTick(payload.count);
    });

    // Inicio de partida activa (30s)
    window.networkSync.on('ROUND_STARTED', (payload) => {
      this.state = 'PLAYING';
      this.timeLeft = payload.duration || 30;
      this.moment = 1;
      this.hiveTargetDrops = payload.targetDrops || 50;
      this.hiveCurrentDrops = 0;
      this.overflowDrops = 0;
      this.localStreak = 0;
      this.localMultiplier = 1;

      if (payload.flowers) {
        this.flowers = payload.flowers;
        if (this.onFlowersUpdated) this.onFlowersUpdated(this.flowers);
      }

      if (window.audioSystem) {
        window.audioSystem.setTempo(112);
        window.audioSystem.startBgm();
        window.audioSystem.playGo();
      }

      if (this.onStateChanged) this.onStateChanged('PLAYING', payload);
    });

    // Actualización de temporizador y cambio de momentos de ritmo
    window.networkSync.on('TIMER_UPDATE', (payload) => {
      this.timeLeft = payload.timeLeft;
      const oldMoment = this.moment;
      this.moment = payload.moment;

      if (this.onTimerTick) this.onTimerTick(this.timeLeft, this.moment);

      if (payload.momentChanged) {
        if (this.onMomentChanged) this.onMomentChanged(this.moment, payload.eventName);

        // Aceleración de audio en Momento 3 (Frenesí de Néctar)
        if (this.moment === 3 && window.audioSystem) {
          window.audioSystem.setTempo(140);
        }
      }
    });

    // Sincronización de flores
    window.networkSync.on('FLOWERS_SYNC', (payload) => {
      if (payload.flowers) {
        this.flowers = payload.flowers;
        if (this.onFlowersUpdated) this.onFlowersUpdated(this.flowers);
      }
    });

    // Notificación de recolección de néctar autoritativa
    window.networkSync.on('NECTAR_COLLECTED', (payload) => {
      // Actualizar flor localmente
      const flower = this.flowers[payload.slotIndex];
      if (flower) {
        flower.state = 'harvested';
        if (this.onFlowerChanged) this.onFlowerChanged(flower);
        setTimeout(() => {
          flower.state = 'recharging';
          if (this.onFlowerChanged) this.onFlowerChanged(flower);
        }, 280);
      }

      // Actualizar colmena colectiva
      if (payload.hive) {
        this.hiveCurrentDrops = payload.hive.currentDrops;
        this.hiveTargetDrops = payload.hive.targetDrops;
        this.overflowDrops = payload.hive.overflow;
      }

      // Si es el jugador local
      if (this.localPlayer && payload.playerId === this.localPlayer.id) {
        this.localPlayer.score += payload.points;
        this.localPlayer.drops += payload.drops;
        this.localStreak = payload.streak;
        this.localMultiplier = payload.multiplier;

        if (this.onLocalScoreUpdated) {
          this.onLocalScoreUpdated(this.localPlayer.score, this.localStreak, this.localMultiplier);
        }
      }

      // Sonido y feedback
      if (window.audioSystem) {
        if (payload.isGolden) window.audioSystem.playGoldenBurst();
        else window.audioSystem.playPop();

        if (payload.coopBonus) {
          window.audioSystem.playComboUp(4);
        } else if (payload.streak === 3 || payload.streak === 6) {
          window.audioSystem.playComboUp(payload.streak);
        }
      }

      if (this.onNectarCollected) this.onNectarCollected(payload);
    });

    // Tarjeta de resultados individuales y reflexiones ecológicas
    window.networkSync.on('PLAYER_RESULT_CARD', (payload) => {
      this.personalResultCard = payload;
      if (this.onPersonalResultReceived) {
        this.onPersonalResultReceived(payload);
      }
    });

    // Final de partida colectivo
    window.networkSync.on('GAME_OVER', (payload) => {
      this.state = 'RESULTS';
      if (window.audioSystem) {
        window.audioSystem.stopBgm();
        window.audioSystem.playVictory();
      }
      if (this.onStateChanged) this.onStateChanged('RESULTS', payload);
    });

    // Reinicio de sala
    window.networkSync.on('ROOM_RESET', (payload) => {
      this.state = 'LOBBY';
      this.timeLeft = this.duration;
      this.moment = 1;
      this.hiveCurrentDrops = 0;
      this.overflowDrops = 0;
      this.localStreak = 0;
      this.localMultiplier = 1;
      this.personalResultCard = null;

      if (payload.flowers) {
        this.flowers = payload.flowers;
        if (this.onFlowersUpdated) this.onFlowersUpdated(this.flowers);
      }

      if (this.onStateChanged) this.onStateChanged('LOBBY', payload);
    });
  }

  // Registro del jugador en el servidor
  registerLocalPlayer({ name, character }) {
    const id = window.networkSync ? window.networkSync.getSenderId() : 'loc_' + Math.random().toString(36).substr(2, 6);
    this.localPlayer = {
      id,
      name: name || 'Abejita',
      character: character || 'nectar',
      score: 0,
      drops: 0
    };

    if (window.networkSync) {
      window.networkSync.send('JOIN_ROOM', {
        id: this.localPlayer.id,
        name: this.localPlayer.name,
        character: this.localPlayer.character
      });
    }

    return this.localPlayer;
  }

  // Toque táctil de una flor desde el cliente móvil
  tapFlower(slotIndex) {
    if (this.state !== 'PLAYING') return false;
    const flower = this.flowers[slotIndex];
    if (!flower || flower.state !== 'active') return false;

    // Enviar acción al servidor autoritativo
    if (window.networkSync) {
      window.networkSync.send('TAP_FLOWER', {
        playerId: this.localPlayer ? this.localPlayer.id : window.networkSync.getSenderId(),
        slotIndex: slotIndex
      });
    }

    // Vibración táctil si el dispositivo lo soporta
    if (navigator.vibrate) {
      navigator.vibrate(flower.isGolden ? [20, 35, 25] : [15]);
    }

    return true;
  }
}

if (typeof window !== 'undefined') {
  window.NectarGameCore = NectarGameCore;
}
