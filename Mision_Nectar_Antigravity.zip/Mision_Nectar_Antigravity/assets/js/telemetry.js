/**
 * BeeStation: Misión Néctar — Módulo de Telemetría Educativa IoT
 * Conexión rigurosa con la arquitectura del proyecto BeeStation (SENA Centro Minero Ambiental)
 * 
 * Hardware real verificado del firmware:
 * - Microcontrolador ESP32 DevKit (WiFi + Criptografía ECDSA P-256 local)
 * - Sensor BME280: Temperatura de nido (°C), Humedad relativa (%) y Presión (hPa)
 * - Sensor BH1750: Iluminancia exterior / luz (lux)
 * - Sensor HX711: Báscula / celda de carga para peso total de la colmena (calibración pendiente)
 * - Micrófono analógico MAX4466: Estimación de frecuencia por cruces por cero con histéresis (sin FFT)
 * - Tarjeta microSD: Almacenamiento local de lecturas de respaldo (no es un sensor)
 */

class BeeStationTelemetryDemo {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.timeOfDay = 10; // Horas (6 a 18)
    this.simData = {
      temp: 34.8, // °C (BME280)
      humidity: 58, // % (BME280)
      pressure: 1012.4, // hPa (BME280)
      lux: 840, // lux (BH1750)
      weight: 42.6, // kg (HX711)
      frequency: 238, // Hz (MAX4466 - Cruces por cero)
      statusText: 'Óptimo - Actividad Normal'
    };
  }

  init() {
    if (!this.container) return;
    this.render();
    this.attachEvents();
  }

  updateTime(hour) {
    this.timeOfDay = hour;

    // Simulación biológica ilustrativa
    let weightDelta = 0;
    let luxVal = 100;
    if (hour <= 8) {
      weightDelta = -0.2;
      luxVal = 250;
    } else if (hour <= 12) {
      weightDelta = -0.6; // Salida de pecoreadoras
      luxVal = 1200;
    } else if (hour <= 16) {
      weightDelta = +1.1; // Retorno con néctar
      luxVal = 950;
    } else {
      weightDelta = +1.8;
      luxVal = 150;
    }

    this.simData.weight = +(41.5 + weightDelta).toFixed(2);
    this.simData.temp = +(34.6 + Math.sin(hour / 3) * 0.3).toFixed(1);
    this.simData.humidity = +(60 - (hour > 12 ? (hour - 12) * 1.2 : 0)).toFixed(0);
    this.simData.pressure = +(1012.0 + Math.cos(hour / 4) * 1.5).toFixed(1);
    this.simData.lux = luxVal;
    this.simData.frequency = Math.floor(230 + Math.sin(hour) * 12);

    this.updateUI();
  }

  render() {
    this.container.innerHTML = `
      <div class="telemetry-panel">
        <!-- Encabezado con Mielita Científica -->
        <div class="telemetry-header">
          <div class="telemetry-avatar" id="telem-mielita-slot"></div>
          <div class="telemetry-title-block">
            <div class="badge-sena">SENA · Centro Minero Ambiental (El Bagre, Antioquia)</div>
            <h2>Monitoreo Apícola No Invasivo con IoT — BeeStation</h2>
            <p class="telemetry-intro">
              "En la naturaleza, abrir la colmena altera la temperatura y estresa a la colonia. 
              El proyecto <strong>BeeStation</strong> utiliza un nodo local <strong>ESP32</strong> 
              con sensores especializados para monitorear el nido de forma autónoma, sin abrir la caja ni depender de servicios externos."
            </p>
          </div>
        </div>

        <!-- Barra de Simulación Horaria -->
        <div class="time-control-card">
          <div class="time-label-row">
            <span><strong>Simulación del Ciclo Diario de Pecoreo:</strong></span>
            <span id="label-cur-hour" class="highlight-time">${this.timeOfDay}:00 hrs (Pecoreo Matutino)</span>
          </div>
          <input type="range" id="time-slider" min="6" max="18" value="${this.timeOfDay}" step="1" class="telemetry-slider" />
          <div class="slider-marks">
            <span>06:00 (Amanecer)</span>
            <span>10:00 (Misión Néctar)</span>
            <span>14:00 (Máxima Iluminación)</span>
            <span>18:00 (Cierre de Piquera)</span>
          </div>
        </div>

        <!-- Matriz de Sensores Reales del Firmware BeeStation -->
        <div class="sensor-cards-grid">
          <!-- Sensor 1: BME280 (Temperatura y Humedad) -->
          <div class="sensor-card">
            <div class="sensor-card-top">
              <span class="sensor-badge">BME280 (I2C)</span>
              <span class="sensor-status-dot green"></span>
            </div>
            <div class="sensor-icon">🌡️</div>
            <div class="sensor-name">Temperatura de Nido</div>
            <div class="sensor-value" id="val-temp">${this.simData.temp} °C</div>
            <div class="sensor-desc">Las abejas regulan el calor de la cría entre 34.5°C y 35.5°C mediante termorregulación colectiva.</div>
            <div class="sensor-mini-bar">
              <div class="sensor-bar-fill" id="bar-temp" style="width: 88%;"></div>
            </div>
          </div>

          <!-- Sensor 2: BME280 (Humedad y Presión) -->
          <div class="sensor-card">
            <div class="sensor-card-top">
              <span class="sensor-badge">BME280 (I2C)</span>
              <span class="sensor-status-dot green"></span>
            </div>
            <div class="sensor-icon">💧</div>
            <div class="sensor-name">Humedad y Presión</div>
            <div class="sensor-value" id="val-hum">${this.simData.humidity} %</div>
            <div class="sensor-desc">Presión: <strong id="val-press">${this.simData.pressure} hPa</strong>. Crucial para prevenir la condensación y fermentación de reservas.</div>
            <div class="sensor-mini-bar">
              <div class="sensor-bar-fill" id="bar-hum" style="width: ${this.simData.humidity}%;"></div>
            </div>
          </div>

          <!-- Sensor 3: BH1750 (Luz ambiental) -->
          <div class="sensor-card">
            <div class="sensor-card-top">
              <span class="sensor-badge">BH1750 (I2C)</span>
              <span class="sensor-status-dot green"></span>
            </div>
            <div class="sensor-icon">☀️</div>
            <div class="sensor-name">Luminosidad Exterior</div>
            <div class="sensor-value" id="val-lux">${this.simData.lux} lux</div>
            <div class="sensor-desc">Registra la luz solar disponible para correlacionar con los horarios de vuelo y pecoreo.</div>
            <div class="sensor-mini-bar">
              <div class="sensor-bar-fill" id="bar-lux" style="width: 70%;"></div>
            </div>
          </div>

          <!-- Sensor 4: HX711 + Celda de Carga (Peso de la colmena) -->
          <div class="sensor-card highlight-honey">
            <div class="sensor-card-top">
              <span class="sensor-badge">HX711 (GPIO 16/4)</span>
              <span class="sensor-status-dot green"></span>
            </div>
            <div class="sensor-icon">⚖️</div>
            <div class="sensor-name">Peso Total Estimado</div>
            <div class="sensor-value" id="val-weight">${this.simData.weight} kg</div>
            <div class="sensor-desc">
              *Nota científica: Celda de carga en calibración continua. El peso varía por ingreso de abejas, consumo y factores ambientales.
            </div>
            <div class="sensor-mini-bar">
              <div class="sensor-bar-fill honey" id="bar-weight" style="width: 74%;"></div>
            </div>
          </div>

          <!-- Sensor 5: Micrófono MAX4466 (Acústica) -->
          <div class="sensor-card">
            <div class="sensor-card-top">
              <span class="sensor-badge">MAX4466 (ADC1)</span>
              <span class="sensor-status-dot green"></span>
            </div>
            <div class="sensor-icon">📡</div>
            <div class="sensor-name">Frecuencia Dominante</div>
            <div class="sensor-value" id="val-freq">${this.simData.frequency} Hz</div>
            <div class="sensor-desc">
              Estimación de frecuencia por cruces por cero con histéresis (acustica.h). Zumbido base de colonia en calma.
            </div>
            <div class="wave-visualizer">
              <div class="wave-bar" style="height: 45%;"></div>
              <div class="wave-bar" style="height: 70%;"></div>
              <div class="wave-bar" style="height: 90%;"></div>
              <div class="wave-bar" style="height: 65%;"></div>
              <div class="wave-bar" style="height: 80%;"></div>
              <div class="wave-bar" style="height: 55%;"></div>
            </div>
          </div>
        </div>

        <!-- Arquitectura del Nodo Local -->
        <div class="hardware-spec-box">
          <div class="hw-chip">
            <span class="hw-icon">⚡</span>
            <div>
              <strong>Nodo Local ESP32 con Criptografía ECDSA</strong>
              <div class="hw-sub">Envío directo mediante POST JSON a api/ingest.php en servidor local. Sin nube ni dependencias de pago.</div>
            </div>
          </div>
          <div class="hw-chip">
            <span class="hw-icon">💾</span>
            <div>
              <strong>Respaldo en microSD (Bus VSPI)</strong>
              <div class="hw-sub">Registro de mediciones locales con marca de tiempo NTP ante pérdidas temporales de enlace Wi-Fi.</div>
            </div>
          </div>
        </div>

        <div class="demo-notice">
          ⚠️ <strong>DATOS DE DEMOSTRACIÓN SIMULADOS:</strong> Este panel es un módulo educativo complementario para ferias científicas. No sustituye las lecturas de producción de una colmena instrumentada.
        </div>
      </div>
    `;

    // Renderizar avatar de Mielita con bata/gafas científicas
    const slot = document.getElementById('telem-mielita-slot');
    if (slot && window.renderBeeSVG) {
      slot.innerHTML = window.renderBeeSVG({
        character: 'mielita',
        expression: 'wink',
        accessory: 'goggles',
        size: 90
      });
    }
  }

  attachEvents() {
    const slider = document.getElementById('time-slider');
    if (slider) {
      slider.addEventListener('input', (e) => {
        this.updateTime(parseInt(e.target.value, 10));
      });
    }
  }

  updateUI() {
    const lblHour = document.getElementById('label-cur-hour');
    const valTemp = document.getElementById('val-temp');
    const valHum = document.getElementById('val-hum');
    const valPress = document.getElementById('val-press');
    const valLux = document.getElementById('val-lux');
    const valWeight = document.getElementById('val-weight');
    const valFreq = document.getElementById('val-freq');

    if (lblHour) {
      let desc = 'Pecoreo Normal';
      if (this.timeOfDay <= 8) desc = 'Salida de Abejas';
      else if (this.timeOfDay <= 12) desc = 'Pico de Recolección de Néctar';
      else if (this.timeOfDay >= 16) desc = 'Retorno Masivo al Nido';
      lblHour.textContent = `${this.timeOfDay}:00 hrs (${desc})`;
    }

    if (valTemp) valTemp.textContent = `${this.simData.temp} °C`;
    if (valHum) valHum.textContent = `${this.simData.humidity} %`;
    if (valPress) valPress.textContent = `${this.simData.pressure} hPa`;
    if (valLux) valLux.textContent = `${this.simData.lux} lux`;
    if (valWeight) valWeight.textContent = `${this.simData.weight} kg`;
    if (valFreq) valFreq.textContent = `${this.simData.frequency} Hz`;
  }
}

if (typeof window !== 'undefined') {
  window.BeeStationTelemetryDemo = BeeStationTelemetryDemo;
}
