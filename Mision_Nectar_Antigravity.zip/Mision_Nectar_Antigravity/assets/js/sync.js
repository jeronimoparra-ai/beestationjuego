/**
 * BeeStation: Misión Néctar — Guardianes del Jardín
 * Cliente de Sincronización Multijugador (WebSocket con reconexión automática y fallback limpio)
 */

class NectarNetworkSync {
  constructor() {
    this.ws = null;
    this.fallbackChannel = null;
    this.listeners = new Map();
    this.isConnected = false;
    this.isUsingWebSocket = false;
    this.clientId = this.getOrCreateClientId();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.reconnectTimer = null;

    this.init();
  }

  getOrCreateClientId() {
    let id = sessionStorage.getItem('beestation_client_id');
    if (!id) {
      id = 'cli_' + Math.random().toString(36).substr(2, 7);
      sessionStorage.setItem('beestation_client_id', id);
    }
    return id;
  }

  init() {
    this.connectWebSocket();
  }

  connectWebSocket() {
    // Si estamos en entorno web HTTP/HTTPS normal
    if (typeof window !== 'undefined' && window.location && (window.location.protocol === 'http:' || window.location.protocol === 'https:')) {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          this.isConnected = true;
          this.isUsingWebSocket = true;
          this.reconnectAttempts = 0;
          this.dispatchLocal('CONNECTION_STATUS', { connected: true, mode: 'websocket' });
        };

        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            this.handleIncoming(data);
          } catch (e) {
            console.warn('Error decodificando mensaje WebSocket:', e);
          }
        };

        this.ws.onclose = () => {
          this.isConnected = false;
          this.dispatchLocal('CONNECTION_STATUS', { connected: false, mode: 'disconnected' });
          this.scheduleReconnect();
        };

        this.ws.onerror = () => {
          // Si falla, activamos fallback local sin duplicar
          if (!this.fallbackChannel && typeof BroadcastChannel !== 'undefined') {
            this.initFallbackChannel();
          }
        };
      } catch (e) {
        this.initFallbackChannel();
      }
    } else {
      // Protocolo file:// o sin servidor
      this.initFallbackChannel();
    }
  }

  scheduleReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = Math.min(3000, 500 * Math.pow(1.5, this.reconnectAttempts));
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => {
        this.connectWebSocket();
      }, delay);
    }
  }

  initFallbackChannel() {
    if (this.fallbackChannel || typeof BroadcastChannel === 'undefined') return;
    try {
      this.fallbackChannel = new BroadcastChannel('beestation_mision_nectar_v2');
      this.fallbackChannel.onmessage = (e) => {
        this.handleIncoming(e.data);
      };
      this.isUsingWebSocket = false;
      this.isConnected = true;
      this.dispatchLocal('CONNECTION_STATUS', { connected: true, mode: 'broadcast_channel' });
    } catch (e) {
      console.warn('Fallback BroadcastChannel no disponible', e);
    }
  }

  on(eventType, callback) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType).push(callback);
  }

  off(eventType, callback) {
    if (!this.listeners.has(eventType)) return;
    const arr = this.listeners.get(eventType).filter(cb => cb !== callback);
    this.listeners.set(eventType, arr);
  }

  send(eventType, payload = {}) {
    const message = {
      type: eventType,
      payload: payload,
      senderId: this.clientId,
      timestamp: Date.now()
    };

    if (this.isUsingWebSocket && this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else if (this.fallbackChannel) {
      // Solo BroadcastChannel: sin localStorage simultáneo para evitar eventos duplicados
      this.fallbackChannel.postMessage(message);
      this.handleIncoming(message);
    }
  }

  handleIncoming(msg) {
    if (!msg || !msg.type) return;
    this.dispatchLocal(msg.type, msg.payload, msg);
    this.dispatchLocal('*', msg.payload, msg);
  }

  dispatchLocal(eventType, payload, rawMsg) {
    const callbacks = this.listeners.get(eventType);
    if (callbacks) {
      callbacks.forEach(cb => {
        try {
          cb(payload, rawMsg);
        } catch (err) {
          console.error(`Error en callback de ${eventType}:`, err);
        }
      });
    }
  }

  getSenderId() {
    return this.clientId;
  }
}

if (typeof window !== 'undefined') {
  window.NectarNetworkSync = NectarNetworkSync;
  window.networkSync = new NectarNetworkSync();
}
