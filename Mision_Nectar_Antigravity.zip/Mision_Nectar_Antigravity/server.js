/**
 * BeeStation: Misión Néctar — Guardianes del Jardín
 * Servidor Autoritativo Local Multijugador (Node.js + HTTP + WebSocket)
 * 
 * Funcionalidades:
 * - Servidor de archivos estáticos (frontend, css, js, docs, assets)
 * - Detección automática de IP LAN y generación de código QR funcional
 * - Estado autoritativo centralizado: Temporizador de 30s, 3 Momentos de juego,
 *   flores activas, cálculo de combos, bonificaciones cooperativas y reflexiones ecológicas
 * - Control de bots desde la consola del organizador
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { WebSocketServer, WebSocket } = require('ws');
const QRCode = require('qrcode');

// Configuración de red y puertos
const PORT = parseInt(process.env.PORT || '8080', 10);
const HOST = process.env.HOST || '0.0.0.0';

// Detección de IP local IPv4 no interna
function getLocalIpAddress() {
  if (process.env.PUBLIC_BASE_URL) {
    return process.env.PUBLIC_BASE_URL;
  }
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

const LAN_IP = getLocalIpAddress();
const MOBILE_ACCESS_URL = `http://${LAN_IP}:${PORT}/mobile.html?room=STAND-SENA-01`;

// Tipos MIME comunes
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.md': 'text/markdown; charset=utf-8'
};

// --- MOTOR DE REFLEXIONES PERSONALIZADAS ---
function generatePlayerReflection(stats) {
  // stats: { normalFlowers, goldenFlowers, bestStreak, coopBonusesParticipated, flowerTypesVisited: Set/Array, totalScore, nectarDrops }
  const visitedCount = Array.isArray(stats.flowerTypesVisited) 
    ? stats.flowerTypesVisited.length 
    : (stats.flowerTypesVisited ? stats.flowerTypesVisited.size : 0);

  let category = 'Abeja solidaria';
  let title = 'Aporte Cooperativo';
  let badge = 'Medalla del Enjambre';
  let reflectionText = '¡Tu aporte hizo la diferencia! En los ecosistemas, cada organismo cumple una función. Las abejas ayudan a mantener la biodiversidad mediante la polinización.';

  // Jerarquía lógica según el comportamiento más distintivo
  if (stats.coopBonusesParticipated >= 2) {
    category = 'Guardián del enjambre';
    title = 'Colaboración Ejemplar';
    badge = 'Medalla Guardián';
    reflectionText = '¡Trabajaste en equipo! Las abejas viven en colonias con diferentes funciones. Su organización y colaboración son fundamentales para el funcionamiento de la colonia.';
  } else if (stats.goldenFlowers >= 3) {
    category = 'Coleccionista dorado';
    title = 'Explorador Especial';
    badge = 'Medalla Dorada';
    reflectionText = '¡Descubriste flores especiales! La diversidad de flores ofrece diferentes recursos a los polinizadores. Conservar plantas nativas y espacios florales ayuda a las abejas.';
  } else if (stats.bestStreak >= 5) {
    category = 'Maestro de los combos';
    title = 'Destreza en Vuelo';
    badge = 'Medalla Relámpago';
    reflectionText = '¡Qué habilidad! Las abejas realizan múltiples viajes en busca de alimento. Su actividad de recolección y polinización ayuda a mantener muchos ecosistemas.';
  } else if (visitedCount >= 4) {
    category = 'Explorador de flores';
    title = 'Curiosidad Botánica';
    badge = 'Medalla Botánica';
    reflectionText = '¡Qué gran explorador! En la naturaleza, las abejas visitan flores y pueden transportar polen entre ellas, ayudando a muchas plantas a reproducirse. Cada visita tiene un propósito.';
  } else if (stats.normalFlowers >= 5) {
    category = 'Amigo de la naturaleza';
    title = 'Constancia Vital';
    badge = 'Medalla Naturaleza';
    reflectionText = '¡Cada aporte cuenta! Las abejas necesitan flores y espacios naturales para encontrar alimento. Proteger sus hábitats ayuda a conservar los polinizadores.';
  }

  return {
    category,
    title,
    badge,
    reflectionText,
    generalCuriosity: '¿Qué pasaría si las abejas desaparecieran? Muchas plantas dependen de los polinizadores para reproducirse. Proteger a las abejas también significa proteger la biodiversidad y los ecosistemas de los que dependemos. ¡Proteger a las abejas también es proteger nuestra vida!',
    pledges: [
      'Cuidar las flores y plantas de mi entorno',
      'Evitar destruir los lugares donde viven los polinizadores',
      'Conocer las plantas nativas de mi región',
      'Compartir con otros la importancia de las abejas'
    ]
  };
}

// --- ESTADO AUTORITATIVO DE LA SALA ---
class GameRoom {
  constructor(id = 'STAND-SENA-01') {
    this.id = id;
    this.state = 'LOBBY'; // LOBBY, COUNTDOWN, PLAYING, RESULTS, TELEMETRY
    this.duration = 30; // 30 segundos exactos
    this.timeLeft = 30;
    this.timerInterval = null;
    this.moment = 1; // 1: 0-5s, 2: 6-20s, 3: 21-30s Frenesí
    
    // Néctar y colmena
    this.hiveTargetDrops = 50;
    this.hiveCurrentDrops = 0;
    this.overflowDrops = 0;
    this.totalScore = 0;

    // Participantes: Map(id => player)
    this.players = new Map();

    // Historial y persistencia de resultados individuales (id => resultCard)
    this.resultsCache = new Map();

    // Flores activas (6 ranuras)
    this.flowerSlotsCount = 6;
    this.flowers = [];
    this.flowerTypes = ['margarita', 'coral', 'azul', 'lavanda', 'rosa'];
    this.initFlowers();

    // Ventana temporal para bonificaciones cooperativas (últimos taps)
    this.recentTaps = []; // { playerId, timestamp, isBot }

    // Bots simulados
    this.bots = [];
    this.botsInterval = null;
    this.botCount = 0;
  }

  initFlowers() {
    this.flowers = [];
    for (let i = 0; i < this.flowerSlotsCount; i++) {
      this.flowers.push({
        slotIndex: i,
        type: this.flowerTypes[i % this.flowerTypes.length],
        state: 'active', // active, harvested, recharging
        isGolden: false,
        rechargeUntil: 0
      });
    }
  }

  // Recalibra la meta de la colmena según participantes humanos reales
  recalculateTarget() {
    const humanCount = Array.from(this.players.values()).filter(p => !p.isBot).length;
    // Mínimo 40, o 15 gotas por jugador humano (asequible en 30s)
    this.hiveTargetDrops = Math.max(40, humanCount * 15);
  }

  addPlayer(clientWs, data) {
    const playerId = data.id || ('usr_' + Math.random().toString(36).substr(2, 6));
    let player = this.players.get(playerId);

    if (!player) {
      player = {
        id: playerId,
        name: data.name || 'Abejita Exploradora',
        character: data.character || 'nectar',
        color: data.color || '#F59E0B',
        score: 0,
        nectarDrops: 0,
        normalFlowers: 0,
        goldenFlowers: 0,
        bestStreak: 0,
        currentStreak: 0,
        coopBonusesParticipated: 0,
        flowerTypesVisited: new Set(),
        isBot: !!data.isBot,
        ws: clientWs
      };
      this.players.set(playerId, player);
    } else {
      player.ws = clientWs;
      if (data.name) player.name = data.name;
      if (data.character) player.character = data.character;
    }

    this.recalculateTarget();
    return player;
  }

  removePlayer(playerId) {
    this.players.delete(playerId);
    this.recalculateTarget();
  }

  startCountdown(broadcastFn) {
    if (this.state === 'COUNTDOWN' || this.state === 'PLAYING') return;
    this.state = 'COUNTDOWN';
    this.initFlowers();

    // Reiniciar contadores de partida de los jugadores
    this.players.forEach(p => {
      p.score = 0;
      p.nectarDrops = 0;
      p.normalFlowers = 0;
      p.goldenFlowers = 0;
      p.bestStreak = 0;
      p.currentStreak = 0;
      p.coopBonusesParticipated = 0;
      p.flowerTypesVisited = new Set();
    });

    this.hiveCurrentDrops = 0;
    this.overflowDrops = 0;
    this.totalScore = 0;
    this.recentTaps = [];

    broadcastFn({
      type: 'START_COUNTDOWN',
      payload: { count: 3 }
    });

    let count = 3;
    const interval = setInterval(() => {
      count--;
      if (count > 0) {
        broadcastFn({
          type: 'COUNTDOWN_TICK',
          payload: { count }
        });
      } else {
        clearInterval(interval);
        this.startRound(broadcastFn);
      }
    }, 1000);
  }

  startRound(broadcastFn) {
    this.state = 'PLAYING';
    this.timeLeft = this.duration;
    this.moment = 1;

    broadcastFn({
      type: 'ROUND_STARTED',
      payload: {
        duration: this.duration,
        targetDrops: this.hiveTargetDrops,
        flowers: this.flowers
      }
    });

    // Temporizador autoritativo de 30 segundos
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.timeLeft--;

      // Momento 1: 0-5s (primer vuelo) -> timeLeft 30 a 26
      // Momento 2: 6-20s (jardín despierta) -> timeLeft 25 a 11
      // Momento 3: 21-30s (frenesí de néctar) -> timeLeft 10 a 0
      let newMoment = 1;
      if (this.timeLeft <= 10) newMoment = 3;
      else if (this.timeLeft <= 25) newMoment = 2;

      const momentChanged = newMoment !== this.moment;
      this.moment = newMoment;

      broadcastFn({
        type: 'TIMER_UPDATE',
        payload: {
          timeLeft: this.timeLeft,
          moment: this.moment,
          momentChanged: momentChanged,
          eventName: this.moment === 3 ? 'LLUVIA_DE_POLEN' : (this.moment === 2 ? 'JARDIN_DESPIERTA' : 'PRIMER_VUELO')
        }
      });

      // Ciclo de regeneración de flores en servidor
      this.tickFlowers(broadcastFn);

      if (this.timeLeft <= 0) {
        clearInterval(this.timerInterval);
        this.timerInterval = null;
        this.endRound(broadcastFn);
      }
    }, 1000);
  }

  tickFlowers(broadcastFn) {
    const now = Date.now();
    let updated = false;

    this.flowers.forEach((flower, idx) => {
      if (flower.state === 'recharging' && now >= flower.rechargeUntil) {
        // Probabilidad de flor dorada según momento
        // Momento 1: 0% dorada (solo flores básicas para aprender)
        // Momento 2: 25% dorada
        // Momento 3: 45% dorada (frenesí)
        let goldChance = 0;
        if (this.moment === 2) goldChance = 0.25;
        else if (this.moment === 3) goldChance = 0.45;

        const isGold = Math.random() < goldChance;
        flower.isGolden = isGold;
        flower.type = isGold ? 'dorada' : this.flowerTypes[Math.floor(Math.random() * this.flowerTypes.length)];
        flower.state = 'active';
        flower.points = isGold ? 30 : 10;
        updated = true;
      }
    });

    if (updated) {
      broadcastFn({
        type: 'FLOWERS_SYNC',
        payload: { flowers: this.flowers }
      });
    }
  }

  handleTap(playerId, slotIndex, broadcastFn) {
    if (this.state !== 'PLAYING') return null;

    const flower = this.flowers[slotIndex];
    if (!flower || flower.state !== 'active') {
      return null; // Idempotencia: flor no disponible o ya cosechada
    }

    const player = this.players.get(playerId);
    if (!player) return null;

    // 1. Estado de la flor: Harvested
    flower.state = 'harvested';
    flower.rechargeUntil = Date.now() + 1100; // 1.1s de recarga
    setTimeout(() => {
      flower.state = 'recharging';
    }, 280);

    // 2. Cálculo de Combo / Racha
    player.currentStreak++;
    if (player.currentStreak > player.bestStreak) {
      player.bestStreak = player.currentStreak;
    }

    let multiplier = 1;
    if (player.currentStreak >= 6) multiplier = 3;
    else if (player.currentStreak >= 3) multiplier = 2;

    const basePoints = flower.isGolden ? 30 : 10;
    const gainedPoints = basePoints * multiplier;
    const gainedDrops = flower.isGolden ? 3 : 1;

    player.score += gainedPoints;
    player.nectarDrops += gainedDrops;
    if (flower.isGolden) player.goldenFlowers++;
    else player.normalFlowers++;
    player.flowerTypesVisited.add(flower.type);

    // 3. Comprobación de Bonificación Cooperativa (Ventana de 2.5s)
    const now = Date.now();
    this.recentTaps.push({ playerId, timestamp: now, isBot: player.isBot });
    // Limpiar taps más antiguos de 2.5s
    this.recentTaps = this.recentTaps.filter(t => now - t.timestamp <= 2500);

    const distinctRealPlayers = new Set(this.recentTaps.filter(t => !t.isBot).map(t => t.playerId));
    let coopBonusTriggered = false;

    // Si al menos 2 jugadores reales (o 1 real + 2 bots en pruebas) tocan dentro de la ventana
    if (distinctRealPlayers.size >= 2) {
      coopBonusTriggered = true;
      // Recompensa cooperativa
      distinctRealPlayers.forEach(pId => {
        const p = this.players.get(pId);
        if (p) {
          p.score += 20;
          p.nectarDrops += 2;
          p.coopBonusesParticipated++;
        }
      });
      // Vaciamos ventana para no disparar en bucle continuo
      this.recentTaps = [];
    }

    // 4. Progreso de la colmena
    const totalDropsGained = gainedDrops + (coopBonusTriggered ? 4 : 0);
    this.totalScore += gainedPoints;

    if (this.hiveCurrentDrops < this.hiveTargetDrops) {
      this.hiveCurrentDrops = Math.min(this.hiveTargetDrops, this.hiveCurrentDrops + totalDropsGained);
    } else {
      this.overflowDrops += totalDropsGained;
    }

    const progressPercent = Math.min(100, Math.floor((this.hiveCurrentDrops / this.hiveTargetDrops) * 100));

    // Difundir evento de recolección
    broadcastFn({
      type: 'NECTAR_COLLECTED',
      payload: {
        playerId,
        playerName: player.name,
        character: player.character,
        isBot: player.isBot,
        slotIndex,
        flowerType: flower.type,
        isGolden: flower.isGolden,
        points: gainedPoints,
        drops: gainedDrops,
        streak: player.currentStreak,
        multiplier,
        coopBonus: coopBonusTriggered,
        hive: {
          currentDrops: this.hiveCurrentDrops,
          targetDrops: this.hiveTargetDrops,
          overflow: this.overflowDrops,
          progressPercent
        }
      }
    });

    return { gainedPoints, gainedDrops, multiplier, coopBonusTriggered };
  }

  endRound(broadcastFn) {
    this.state = 'RESULTS';
    if (this.botsInterval) clearInterval(this.botsInterval);

    // Generar y almacenar tarjetas de resultados individuales para cada jugador humano
    this.resultsCache.clear();
    const sortedPlayers = Array.from(this.players.values()).sort((a, b) => b.score - a.score);

    this.players.forEach(player => {
      if (!player.isBot) {
        const card = {
          playerId: player.id,
          playerName: player.name,
          character: player.character,
          score: player.score,
          nectarDrops: player.nectarDrops,
          normalFlowers: player.normalFlowers,
          goldenFlowers: player.goldenFlowers,
          bestStreak: player.bestStreak,
          coopBonuses: player.coopBonusesParticipated,
          reflection: generatePlayerReflection({
            normalFlowers: player.normalFlowers,
            goldenFlowers: player.goldenFlowers,
            bestStreak: player.bestStreak,
            coopBonusesParticipated: player.coopBonusesParticipated,
            flowerTypesVisited: Array.from(player.flowerTypesVisited),
            totalScore: player.score,
            nectarDrops: player.nectarDrops
          })
        };
        this.resultsCache.set(player.id, card);

        // Envío directo a su WebSocket
        if (player.ws && player.ws.readyState === WebSocket.OPEN) {
          player.ws.send(JSON.stringify({
            type: 'PLAYER_RESULT_CARD',
            payload: card
          }));
        }
      }
    });

    // Difusión global para TV y Organizador
    broadcastFn({
      type: 'GAME_OVER',
      payload: {
        totalScore: this.totalScore,
        hiveDrops: this.hiveCurrentDrops,
        targetDrops: this.hiveTargetDrops,
        overflowDrops: this.overflowDrops,
        progressPercent: Math.min(100, Math.floor((this.hiveCurrentDrops / this.hiveTargetDrops) * 100)),
        topPlayers: sortedPlayers.slice(0, 5).map(p => ({
          id: p.id,
          name: p.name,
          character: p.character,
          score: p.score,
          drops: p.nectarDrops,
          isBot: p.isBot
        }))
      }
    });
  }

  resetRoom(broadcastFn) {
    this.state = 'LOBBY';
    this.timeLeft = this.duration;
    this.moment = 1;
    this.hiveCurrentDrops = 0;
    this.overflowDrops = 0;
    this.totalScore = 0;
    this.recentTaps = [];
    if (this.timerInterval) clearInterval(this.timerInterval);
    if (this.botsInterval) clearInterval(this.botsInterval);

    this.initFlowers();

    broadcastFn({
      type: 'ROOM_RESET',
      payload: {
        state: 'LOBBY',
        targetDrops: this.hiveTargetDrops,
        flowers: this.flowers
      }
    });
  }

  // --- ADMINISTRADOR DE BOTS ---
  setBots(count, broadcastFn) {
    this.botCount = Math.max(0, Math.min(50, count));

    // Eliminar bots antiguos
    const botIds = Array.from(this.players.keys()).filter(id => this.players.get(id).isBot);
    botIds.forEach(id => this.players.delete(id));

    const chars = ['nectar', 'menta', 'coral', 'lavanda', 'cielo', 'durazno'];
    const botNames = ['Zumbador', 'Poli-Bot', 'Alita', 'RayoMiel', 'Solcito', 'Brisa', 'Chispita', 'Florecita'];

    for (let i = 0; i < this.botCount; i++) {
      const bId = 'bot_' + (i + 1);
      this.players.set(bId, {
        id: bId,
        name: `${botNames[i % botNames.length]} #${i + 1}`,
        character: chars[i % chars.length],
        color: '#F59E0B',
        score: 0,
        nectarDrops: 0,
        normalFlowers: 0,
        goldenFlowers: 0,
        bestStreak: 0,
        currentStreak: 0,
        coopBonusesParticipated: 0,
        flowerTypesVisited: new Set(),
        isBot: true,
        ws: null
      });
    }

    this.recalculateTarget();

    // Loop de actividad de bots si la partida está en marcha
    if (this.botsInterval) clearInterval(this.botsInterval);
    if (this.botCount > 0) {
      this.botsInterval = setInterval(() => {
        if (this.state !== 'PLAYING') return;

        const activeSlots = this.flowers.map((f, i) => f.state === 'active' ? i : -1).filter(i => i !== -1);
        if (activeSlots.length === 0) return;

        const randomSlot = activeSlots[Math.floor(Math.random() * activeSlots.length)];
        const botList = Array.from(this.players.values()).filter(p => p.isBot);
        if (botList.length > 0) {
          const randomBot = botList[Math.floor(Math.random() * botList.length)];
          this.handleTap(randomBot.id, randomSlot, broadcastFn);
        }
      }, Math.max(160, 2400 / Math.max(1, this.botCount)));
    }

    broadcastFn({
      type: 'PLAYERS_UPDATED',
      payload: {
        count: this.players.size,
        humanCount: Array.from(this.players.values()).filter(p => !p.isBot).length,
        botCount: this.botCount,
        players: Array.from(this.players.values()).map(p => ({
          id: p.id,
          name: p.name,
          character: p.character,
          score: p.score,
          isBot: p.isBot
        }))
      }
    });
  }
}

// Instancia única de la sala
const room = new GameRoom();

// --- SERVIDOR HTTP ---
const baseDir = __dirname;

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  let pathname = parsedUrl.pathname;

  // Endpoint de información de sala y dirección de red
  if (pathname === '/api/info') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      lanIp: LAN_IP,
      port: PORT,
      mobileUrl: MOBILE_ACCESS_URL,
      state: room.state,
      timeLeft: room.timeLeft,
      moment: room.moment,
      playersCount: room.players.size,
      hiveProgress: Math.min(100, Math.floor((room.hiveCurrentDrops / room.hiveTargetDrops) * 100))
    }));
    return;
  }

  // Endpoint de generación de QR en vivo (SVG auténtico)
  if (pathname === '/api/qr') {
    try {
      const qrSvg = await QRCode.toString(MOBILE_ACCESS_URL, {
        type: 'svg',
        color: { dark: '#1C1C1E', light: '#FFFFFF' },
        margin: 1
      });
      res.writeHead(200, { 'Content-Type': 'image/svg+xml' });
      res.end(qrSvg);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Error generando QR');
    }
    return;
  }

  // Servir archivos estáticos
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.join(baseDir, pathname);

  // Seguridad: evitar directory traversal fuera del proyecto
  if (!filePath.startsWith(baseDir)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Acceso denegado');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Archivo no encontrado');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, { 'Content-Type': contentType });
    fs.createReadStream(filePath).pipe(res);
  });
});

// --- SERVIDOR WEBSOCKET ---
const wss = new WebSocketServer({ server });

function broadcast(msg) {
  const json = JSON.stringify(msg);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(json);
    }
  });
}

wss.on('connection', (ws) => {
  let attachedPlayerId = null;

  // Enviar estado actual completo al cliente recién conectado
  ws.send(JSON.stringify({
    type: 'ROOM_STATE',
    payload: {
      room: room.id,
      state: room.state,
      timeLeft: room.timeLeft,
      moment: room.moment,
      targetDrops: room.hiveTargetDrops,
      currentDrops: room.hiveCurrentDrops,
      overflowDrops: room.overflowDrops,
      flowers: room.flowers,
      playersCount: room.players.size,
      lanIp: LAN_IP,
      mobileUrl: MOBILE_ACCESS_URL
    }
  }));

  ws.on('message', (messageRaw) => {
    try {
      const data = JSON.parse(messageRaw);
      const { type, payload } = data;

      switch (type) {
        case 'JOIN_ROOM': {
          const player = room.addPlayer(ws, payload || {});
          attachedPlayerId = player.id;

          ws.send(JSON.stringify({
            type: 'JOINED_SUCCESS',
            payload: {
              playerId: player.id,
              name: player.name,
              character: player.character
            }
          }));

          // Si el juego ya está en RESULTS y este jugador ya tenía tarjeta calculada, enviársela de inmediato
          if (room.state === 'RESULTS' && room.resultsCache.has(player.id)) {
            ws.send(JSON.stringify({
              type: 'PLAYER_RESULT_CARD',
              payload: room.resultsCache.get(player.id)
            }));
          }

          broadcast({
            type: 'PLAYERS_UPDATED',
            payload: {
              count: room.players.size,
              humanCount: Array.from(room.players.values()).filter(p => !p.isBot).length,
              botCount: room.botCount,
              players: Array.from(room.players.values()).map(p => ({
                id: p.id,
                name: p.name,
                character: p.character,
                score: p.score,
                isBot: p.isBot
              }))
            }
          });
          break;
        }

        case 'START_COUNTDOWN': {
          room.startCountdown(broadcast);
          break;
        }

        case 'TAP_FLOWER': {
          if (payload && payload.slotIndex !== undefined) {
            const pId = payload.playerId || attachedPlayerId;
            room.handleTap(pId, payload.slotIndex, broadcast);
          }
          break;
        }

        case 'RESET_ROOM': {
          room.resetRoom(broadcast);
          break;
        }

        case 'SET_BOTS': {
          room.setBots(payload.count || 0, broadcast);
          break;
        }

        case 'SWITCH_TELEMETRY': {
          room.state = 'TELEMETRY';
          broadcast({ type: 'STATE_CHANGED', payload: { state: 'TELEMETRY' } });
          break;
        }

        default:
          break;
      }
    } catch (err) {
      console.error('Error procesando mensaje WebSocket:', err);
    }
  });

  ws.on('close', () => {
    if (attachedPlayerId) {
      const p = room.players.get(attachedPlayerId);
      if (p && !p.isBot) {
        // En lugar de borrar de inmediato, mantenemos por si reconecta
        p.ws = null;
      }
    }
  });
});

// Iniciar escucha del servidor
server.listen(PORT, HOST, () => {
  console.log('================================================================');
  console.log('🐝 BEESTATION: MISIÓN NÉCTAR — GUARDIANES DEL JARDÍN (V2)');
  console.log(`📡 Servidor Local WebSocket + HTTP activo en puerto: ${PORT}`);
  console.log(`🌐 Acceso Pantalla TV: http://localhost:${PORT}/tv.html`);
  console.log(`📱 Acceso Celulares LAN: ${MOBILE_ACCESS_URL}`);
  console.log(`🎛️ Consola Organizador: http://localhost:${PORT}/organizer.html`);
  console.log(`🔬 Telemetría BeeStation IoT: http://localhost:${PORT}/telemetry.html`);
  console.log('================================================================');
});
